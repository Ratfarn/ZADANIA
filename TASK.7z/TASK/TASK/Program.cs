﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TASK
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Ввод количества поставщиков
            int m;
            do
            {
                Console.Write("Введите количество поставщиков: ");
            } while (!int.TryParse(Console.ReadLine(), out m) || m <= 0);

            // Ввод количества потребителей
            int n;
            do
            {
                Console.Write("Введите количество потребителей: ");
            } while (!int.TryParse(Console.ReadLine(), out n) || n <= 0);

            // Ввод цен за перевозку
            int[,] costs = new int[m, n];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    int cost;
                    do
                    {
                        Console.Write($"Введите стоимость перевозки из поставщика {i + 1} в потребитель {j + 1}: ");
                    } while (!int.TryParse(Console.ReadLine(), out cost) || cost < 0);
                    costs[i, j] = cost;
                }
            }

            // Расчет опорного плана с методом северо-западного угла
            int[,] plan = new int[m, n];
            int[] supply = new int[m];
            int[] demand = new int[n];
            for (int i = 0; i < m; i++)
            {
                Console.WriteLine($"Введите количество для поставщика {i + 1}:");
                supply[i] = int.Parse(Console.ReadLine());
            }
            for (int j = 0; j < n; j++)
            {
                Console.WriteLine($"Введите количество для потребителя {j + 1}:");
                demand[j] = int.Parse(Console.ReadLine());
            }

            int iSupply = 0;
            int jDemand = 0;
            while (iSupply < m && jDemand < n)
            {
                int quantity = Math.Min(supply[iSupply], demand[jDemand]);
                plan[iSupply, jDemand] = quantity;
                supply[iSupply] -= quantity;
                demand[jDemand] -= quantity;

                if (supply[iSupply] == 0)
                {
                    iSupply++;
                }

                if (demand[jDemand] == 0)
                {
                    jDemand++;
                }
            }

            // Вывод опорного плана
            Console.WriteLine("\nОпорный план:");
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write($"{plan[i, j]}\t");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        } 
    }
}
