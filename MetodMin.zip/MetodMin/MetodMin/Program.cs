﻿using System;

class MetodMin
{
    static void Main()
    {
        Console.WriteLine("Введите количество поставщиков:");
        int numSources = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите количество потребителей:");
        int numDestinations = int.Parse(Console.ReadLine());

        int[,] supplies = new int[numSources, 1];
        int[,] demands = new int[1, numDestinations];
        int[,] costs = new int[numSources, numDestinations];
        int[,] allocations = new int[numSources, numDestinations];

        // Ввод запасов источников
        for (int i = 0; i < numSources; i++)
        {
            Console.WriteLine($"Введите запас поставщика {i + 1}:");
            supplies[i, 0] = int.Parse(Console.ReadLine());
        }

        // Ввод потребностей потребителей
        for (int i = 0; i < numDestinations; i++)
        {
            Console.WriteLine($"Введите потребность потребителя {i + 1}:");
            demands[0, i] = int.Parse(Console.ReadLine());
        }

        // Ввод стоимостей перевозки грузов между источниками и потребителями
        for (int i = 0; i < numSources; i++)
        {
            for (int j = 0; j < numDestinations; j++)
            {
                Console.WriteLine($"Введите стоимость перевозки груза от поставщика {i + 1} к потребителю {j + 1}:");
                costs[i, j] = int.Parse(Console.ReadLine());
            }
        }

        int source = 0;
        int dest = 0;
        while (source < numSources && dest < numDestinations)
        {
            int minCost = int.MaxValue;

            // Находим ячейку с минимальной стоимостью в текущей строке
            for (int j = 0; j < numDestinations; j++)
            {
                if (costs[source, j] < minCost && demands[0, j] > 0)
                {
                    minCost = costs[source, j];
                    dest = j;
                }
            }

            // Если не нашли ячейку с отрицательным коэффициентом, переходим к следующей строке
            if (minCost == int.MaxValue)
            {
                source++;
                continue;
            }

            // Иначе находим количество груза, которое можно перевезти
            int quantity = Math.Min(supplies[source, 0], demands[0, dest]);
            allocations[source, dest] = quantity;

            // Уменьшаем оставшиеся запасы и потребности
            supplies[source, 0] -= quantity;
            demands[0, dest] -= quantity;

            // Если запас текущего источника исчерпан, переходим к следующему источнику
            if (supplies[source, 0] == 0)
                source++;
        }

        // Выводим результат
        Console.WriteLine("Оптимальный план:");
        for (int i = 0; i < numSources; i++)
        {
            for (int j = 0; j < numDestinations; j++)
            {
                Console.Write($"{allocations[i, j]}\t");
            }
            Console.WriteLine();
        }

        // Считаем общую стоимость
        int totalCost = 0;
        for (int i = 0; i < numSources; i++)
        {
            for (int j = 0; j < numDestinations; j++)
            {
                totalCost += allocations[i, j] * costs[i, j];
            }
        }

        Console.WriteLine($"Общая стоимость: {totalCost}");
    }
}